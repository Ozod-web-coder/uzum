import {Text, View} from "react-native";


export default function Katalog(){
    return (
        <View>
            <Text>Hello</Text>
        </View>
    )
}