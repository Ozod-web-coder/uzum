import {View, Text} from "react-native";


export function LoginScreen(){

    return (
        <View>
            <Text>
                Hello Login
            </Text>
        </View>
    )
}