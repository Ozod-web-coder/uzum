import {Text, View} from "react-native";


export default function Basket(){
    return (
        <View>
            <Text>Hello</Text>
        </View>
    )
}